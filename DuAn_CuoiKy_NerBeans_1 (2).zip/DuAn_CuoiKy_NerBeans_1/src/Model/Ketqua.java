/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author ADMIN
 */
public class Ketqua {
    public static int dapancuaban;
      public static int diem;
       public static int dapan;
    String DapAnCuaBan,Dapan ;
    int Diem;

    public Ketqua(String DapAnCuaBan, String Dapan, int Diem) {
        this.DapAnCuaBan = DapAnCuaBan;
        this.Dapan = Dapan;
        this.Diem = Diem;
    }

    public Ketqua() {
        
    }

    public String getDapAnCuaBan() {
        return DapAnCuaBan;
    }

    public void setDapAnCuaBan(String DapAnCuaBan) {
        this.DapAnCuaBan = DapAnCuaBan;
    }

    public String getDapan() {
        return Dapan;
    }

    public void setDapan(String Dapan) {
        this.Dapan = Dapan;
    }

    public int getDiem() {
        return Diem;
    }

    public void setDiem(int Diem) {
        this.Diem = Diem;
    }
     public Ketqua(String DapAnCuaBan, int Diem) {
        this.DapAnCuaBan = DapAnCuaBan;
        this.Diem = Diem;
    }
}

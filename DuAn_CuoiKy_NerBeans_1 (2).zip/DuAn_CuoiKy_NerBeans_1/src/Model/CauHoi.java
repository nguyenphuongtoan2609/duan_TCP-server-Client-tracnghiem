/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author ADMIN
 */
public class CauHoi {
     private int cauhoi,MaCH;
    private String NoiDung, CauA, CauB,CauC,CauD,DapAn,capDo;
 private int maDT, maLCH, maNCH;
 
    public CauHoi( int MaCH, int cauhoi, String NoiDung, String CauA, String CauB, String CauC, String CauD, String DapAn, String capDo, int maDT, int maLCH, int maNCH) {
            this.MaCH = MaCH;
        this.cauhoi = cauhoi;
   
        this.NoiDung = NoiDung;
        this.CauA = CauA;
        this.CauB = CauB;
        this.CauC = CauC;
        this.CauD = CauD;
        this.DapAn = DapAn;
        this.capDo=capDo;
           this.maDT = maDT;
        this.maLCH = maLCH;
        this.maNCH = maNCH;
    }


    public String getCapDo() {
        return capDo;
    }

    public void setCapDo(String capDo) {
        this.capDo = capDo;
    }

   public int getCauhoi() {
        return cauhoi;
    }

    public void setCauhoi(int cauhoi) {
        this.cauhoi = cauhoi;
    }

    public int getMaCH() {
        return MaCH;
    }

    public void setMaCH(int MaCH) {
        this.MaCH = MaCH;
    }

    public String getNoiDung() {
        return NoiDung;
    }

    public void setNoiDung(String NoiDung) {
        this.NoiDung = NoiDung;
    }

    public String getCauA() {
        return CauA;
    }

    public void setCauA(String CauA) {
        this.CauA = CauA;
    }

    public String getCauB() {
        return CauB;
    }

    public void setCauB(String CauB) {
        this.CauB = CauB;
    }

    public String getCauC() {
        return CauC;
    }

    public void setCauC(String CauC) {
        this.CauC = CauC;
    }

    public String getCauD() {
        return CauD;
    }

    public void setCauD(String CauD) {
        this.CauD = CauD;
    }

    public String getDapAn() {
        return DapAn;
    }

    public void setDapAn(String DapAn) {
        this.DapAn = DapAn;
    }
     public int getMaDT() {
        return maDT;
    }

    public void setMaDT(int maDT) {
        this.maDT = maDT;
    }

    public int getMaLCH() {
        return maLCH;
    }

    public void setMaLCH(int maLCH) {
        this.maLCH = maLCH;
    }

    public int getMaNCH() {
        return maNCH;
    }

    public void setMaNCH(int maNCH) {
        this.maNCH = maNCH;
    }
    @Override
    public String toString()
    {
        return "CauHoi{"+"iMaCH="+ MaCH +", CAUHOI="+ cauhoi+", NOIDUNG="+NoiDung+", CauA="+ CauA+", CauB="+CauB +", CauC="+CauC + ", CauD="+CauD+", DAP_AN="+DapAn+ ", capDo=" + capDo + ", maDT=" + maDT + ", maLCH=" + maLCH + ", maNCH=" + maNCH +"}" ;
    }
    public static void main(String[] args) {
        double d=321.0;
        System.out.println((int)d);
    }
}

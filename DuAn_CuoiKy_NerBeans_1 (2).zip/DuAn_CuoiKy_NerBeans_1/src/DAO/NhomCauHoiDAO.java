/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Model.NhomCauHoi;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import php_connect.ConnectPHP;

/**
 *
 * @author ADMIN
 */
public class NhomCauHoiDAO {
    //hàm trả về danh sách nhóm câu hỏi
    public static List<NhomCauHoi> selectAll(){
        List<NhomCauHoi> list = new ArrayList<>();
        String sql = "select * from NhomCauHoi";
        try(PreparedStatement ps =ConnectPHP.getDBConnection().prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            while(rs.next()){
                list.add(new NhomCauHoi(rs.getInt("MaNCH"), rs.getString("TenNCH"), rs.getString("NoiDung")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}

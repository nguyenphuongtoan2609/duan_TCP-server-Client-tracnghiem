/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import php_connect.ConnectPHP;
import Model.CauHoi;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author ADMIN
 */
public class CauHoiDAO {
    //hàm trả về mã đề thi ngẫu nhiên trong cấp độ
    public static int getExamId(String capDo) {
        List<Integer> listIntegers = new ArrayList<>();
        String sql = "select * from DeThi A inner join CapDo B on A.MaCD = B.MaCD where B.TenCD =?";
        try (PreparedStatement ps = ConnectPHP.getDBConnection().prepareStatement(sql)) {
            ps.setString(1, capDo);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                listIntegers.add(rs.getInt("MaDT"));
            }
            if (listIntegers.size() == 0) {
                return -1;
            } else {
                Random rd = new Random();
                int x = rd.nextInt(listIntegers.size());
                return listIntegers.get(x);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }
      //hàm lấy danh sách câu hỏi theo độ khó
    public static List<CauHoi> selectAll(int maDT, String capDo, int maNCH) {
        List<CauHoi> list = new ArrayList<CauHoi>();
        String sql = "select * from tbtracnghiem where MaDT = ? and CapDo = ? and MaNCH = ?";
        try (PreparedStatement ps = ConnectPHP.getDBConnection().prepareStatement(sql);) {
            ps.setInt(1, maDT);
            ps.setString(2, capDo);
            ps.setInt(3, maNCH);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new CauHoi(rs.getInt("MaCH"),
                        rs.getInt("CAUHOI"),
                        rs.getString("NOIDUNG"),
                        rs.getString("A"),
                      rs.getString("B"),
                        rs.getString("C"),
                        rs.getString("D"),
                        rs.getString("DAP_AN"),
                        rs.getString("CapDo"),
                         rs.getInt("MaDT"),
                        rs.getInt("MaLCH"),
                        rs.getInt("MaNCH")));                 
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public static List<CauHoi> selectCauHoi(int maDT) {
        //tạo list chưa danh sách câu hỏi
        List<CauHoi> list = new ArrayList<>();
        //tạo list chưa danh sách câu hỏi Easy
        List<CauHoi> listEasy = selectAll(maDT, "Easy", 2);
        //tạo list chưa danh sách câu hỏi Medium
        List<CauHoi> listMedium = selectAll(maDT, "Medium", 2);
        //tạo list chưa danh sách câu hỏi Hard
        List<CauHoi> listHard = selectAll(maDT, "Hard", 2);
        /*
            thêm 5 câu hỏi dễ vào list
                i. lấy 1 list random 5 số
                2. thêm vào danh sách
         */
        int lenEasy = listEasy.size();
        List<Integer> randomEasy = randomList(lenEasy, 5);
        for (int i = 0; i < randomEasy.size(); i++) {
            list.add(listEasy.get(randomEasy.get(i)));
        }
        /*
            thêm 3 câu hỏi trung bình vào list
                i. lấy 1 list random 3 số
                2. thêm vào danh sách
         */
        int lenMedium = listMedium.size();
        List<Integer> randomMedium = randomList(lenMedium, 3);
        for (int i = 0; i < randomMedium.size(); i++) {
            list.add(listMedium.get(randomMedium.get(i)));
        }
        /*
            thêm 2 câu hỏi khó vào list
                i. lấy 1 list random 2 số
                2. thêm vào danh sách
         */
        int lenHard = listHard.size();
        List<Integer> randomHard = randomList(lenHard, 2);
        for (int i = 0; i < randomHard.size(); i++) {
            list.add(listHard.get(randomHard.get(i)));
        }
        return list;
    }

    //hàm lấy list random
    public static List<Integer> randomList(int max, int count) {
        List<Integer> list = new ArrayList<>();
        Random rd = new Random();
        while (list.size() < count) {
            int x = rd.nextInt(max);
            boolean flag = false;
            for (int i : list) {
                if (x == i) {
                    flag = true;
                }
            }
            if (!flag) {
                list.add(x);
            }
        }
        return list;
    }

    public static List<CauHoi> getList(String tenDT, String tenNCH) {
        List<CauHoi> list = new ArrayList<>();
        String sql = "exec Usp_CauH ?, ?";
        try (CallableStatement cs = ConnectPHP.getDBConnection().prepareCall(sql)) {
            cs.setString(1, tenDT);
            cs.setString(2, tenNCH);
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
               list.add(new CauHoi(rs.getInt("MaCH"),
                        rs.getInt("CAUHOI"),
                        rs.getString("NOIDUNG"),
                        rs.getString("A"),
                      rs.getString("B"),
                        rs.getString("C"),
                        rs.getString("D"),
                        rs.getString("DAP_AN"),
                        rs.getString("CapDo"),
                         rs.getInt("MaDT"),
                        rs.getInt("MaLCH"),
                        rs.getInt("MaNCH"))); 
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    //Hàm lấy loại câu hỏi
 public static String getTenLCH(int maLCH) {
        String res = "";
        String sql = "select TenLCH from LoaiCauHoi where MaLCH =?";
        try (PreparedStatement ps = ConnectPHP.getDBConnection().prepareStatement(sql)) {
            ps.setInt(1, maLCH);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                res = rs.getString("TenLCH");
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }
  //hàm lấy mã ch cuối cùng
    public static int getLastId() {
        int res = -1;
        String sql = "select * from tbtracnghiem order by MaCH desc";
        try (PreparedStatement ps = ConnectPHP.getDBConnection().prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                res = rs.getInt("MaCH");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }
    //hàm lấy mã ch cuối cùng
    public static CauHoi getCauHoi(int maCH) {
        String sql = "select * from tbtracnghiem where MaCH=?";
        try (PreparedStatement ps = ConnectPHP.getDBConnection().prepareStatement(sql);) {
            ps.setInt(1, maCH);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                CauHoi cauHoi=new CauHoi(rs.getInt("MaCH"),
                        rs.getInt("CAUHOI"),
                        rs.getString("NOIDUNG"),
                        rs.getString("A"),
                      rs.getString("B"),
                        rs.getString("C"),
                        rs.getString("D"),
                        rs.getString("DAP_AN"),
                        rs.getString("CapDo"),
                         rs.getInt("MaDT"),
                        rs.getInt("MaLCH"),
                        rs.getInt("MaNCH")); 
                return  cauHoi;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static void writeHeader(Sheet sheet, int rowIndex) {
        //create Cellstyle
        Row row = sheet.createRow(rowIndex);

        CellStyle cellStyle = createStyleForHeader(sheet);
        //create cells
        Cell cell = row.createCell(0);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("Mã CH");

        cell = row.createCell(1);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("CAUHOI");

        cell = row.createCell(2);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("NOIDUNG");

        cell = row.createCell(3);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("A");

        cell = row.createCell(4);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("B");

        cell = row.createCell(5);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("C");

        cell = row.createCell(6);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("D");

        cell = row.createCell(7);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("DAP_AN");

        cell = row.createCell(8);
        cell.setCellStyle(cellStyle);
            cell.setCellValue("Cap do");

        cell = row.createCell(9);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("Ma de thi");

        cell = row.createCell(10);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("Loai câu hỏi");

       cell = row.createCell(11);
        cell.setCellStyle(cellStyle);
        cell.setCellValue("Nhóm câu hỏi");

        
    }
     private static CellStyle createStyleForHeader(Sheet sheet) {
        // Create font
        Font font = sheet.getWorkbook().createFont();
        font.setFontName("Times New Roman");
        font.setBold(true);
        font.setFontHeightInPoints((short) 14); // font size
        font.setColor(IndexedColors.WHITE.getIndex()); // text color

        // Create CellStyle
        CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
        cellStyle.setFont(font);
        cellStyle.setFillForegroundColor(IndexedColors.BLUE.getIndex());
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        return cellStyle;
    }
// Auto resize column width
    public static void autosizeColumn(Sheet sheet, int lastColumn) {
        for (int columnIndex = 0; columnIndex < lastColumn; columnIndex++) {
            sheet.autoSizeColumn(columnIndex);
        }
    }

    public static void writeFile(String path, XSSFWorkbook workbook) {
        try {
            File file = new File(path);
            FileOutputStream fos = new FileOutputStream(file);
            workbook.write(fos);
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void writeData(Sheet sheet, List<CauHoi> list) {
        if (list != null) {
            int len = list.size();
            for (int i = 0; i < len; i++) {
                CauHoi ch = list.get(i);
                Row row = sheet.createRow(1 + i);
                Cell cell = row.createCell(0);
                cell.setCellValue(ch.getMaCH() + 320);

                cell = row.createCell(1);
                cell.setCellValue(ch.getCauhoi());

                cell = row.createCell(2);
                cell.setCellValue(ch.getNoiDung());

                cell = row.createCell(3);
                cell.setCellValue(ch.getCauA());

                cell = row.createCell(4);
                cell.setCellValue(ch.getCauB());

                cell = row.createCell(5);
                cell.setCellValue(ch.getCauC());

                cell = row.createCell(6);
                cell.setCellValue(ch.getCauD());

                cell = row.createCell(7);
                cell.setCellValue(ch.getDapAn());

                cell = row.createCell(8);
                cell.setCellValue(ch.getCapDo());

                 cell = row.createCell(9);
                cell.setCellValue(ch.getMaDT() + 4);

                cell = row.createCell(10);
                cell.setCellValue(ch.getMaLCH());

                cell = row.createCell(11);
                cell.setCellValue(ch.getMaNCH());

               
            }
        }
    }
    public static void main(String[] args) {
        try {
            List<CauHoi> list = new ArrayList<>();
            String sql = "Select * from CauHoi where MaDT = 4";
            try (PreparedStatement ps = ConnectPHP.getDBConnection().prepareStatement(sql);
                    ResultSet rs = ps.executeQuery();) {
                while (rs.next()) {
                    list.add(new CauHoi(rs.getInt("MaCH"),
                        rs.getInt("CAUHOI"),
                        rs.getString("NOIDUNG"),
                        rs.getString("A"),
                      rs.getString("B"),
                        rs.getString("C"),
                        rs.getString("D"),
                        rs.getString("DAP_AN"),
                        rs.getString("CapDo"),
                         rs.getInt("MaDT"),
                        rs.getInt("MaLCH"),
                        rs.getInt("MaNCH"))); 
                }
                rs.close();
                  XSSFWorkbook workbook = new XSSFWorkbook();
                XSSFSheet sheet = workbook.createSheet("ThiTNex");
                //create header
                writeHeader(sheet, 0);
                //create data
                writeData(sheet, list);
                int num = sheet.getRow(0).getPhysicalNumberOfCells();
                autosizeColumn(sheet, num);
                //ghi file
                final String path = "C:\\Users\\ADMIN\\Desktop\\Toàn\\ThiTNex.xlsx";
                writeFile(path, workbook);
            } catch (Exception e) {
            }          
        }catch (Exception e) {
            e.printStackTrace();
            }
            }
    }


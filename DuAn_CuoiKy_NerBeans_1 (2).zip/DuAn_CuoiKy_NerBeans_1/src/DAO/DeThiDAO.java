/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Model.DeThi;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import php_connect.ConnectPHP;
/**
 *
 * @author ADMIN
 */
public class DeThiDAO {
    //Ham lay danh sach đề thi theo cấp độ
    public static List<DeThi> selectByLevel(String capDo)
    {
        List<DeThi> list =new ArrayList<>();
        String sql ="select * from DeThi A inner join CapDo B on A.MaCD = B.MaCD where TenCD = ? ";
        try (PreparedStatement ps=ConnectPHP.getDBConnection().prepareStatement(sql)){
            ps.setString (1,capDo);
            ResultSet rs =ps.executeQuery();
            while(rs.next())
            {
                list.add(new DeThi(rs.getInt("MaDT"),rs.getString("TenDT"),rs.getInt("ThoiGian"),rs.getInt("MaCD")));
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  list;
    }
    
    //Hàm lấy thời gian thi
    public static int getTime(int maDT)
    {
        int time=0;
        String sql="select ThoiGian from DeThi where MaDT=?";
        try(PreparedStatement ps =ConnectPHP.getDBConnection().prepareStatement(sql))
        {
            ps.setInt(1,maDT);
            ResultSet rs =ps.executeQuery();
            if(rs.next())
            {
                time=rs.getInt("ThoiGian");
            }
        }
        catch(Exception e)
        { e.printStackTrace();
        }
        return  time;
    }
    //hàm trả về tên đề thi
    public static String getName(int maDT) {
        String res = "";
        String sql = "select TenDT from DeThi where MaDT =?";
        try (PreparedStatement ps = ConnectPHP.getDBConnection().prepareStatement(sql)) {
            ps.setInt(1, maDT);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                res = rs.getString("TenDT");
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    //hàm trả về mã đề thi
    public static int getID(String tenDT) {
        int res = -1;
        String sql = "select MaDT from DeThi where TenDT =?";
        try (PreparedStatement ps = ConnectPHP.getDBConnection().prepareStatement(sql)) {
            ps.setString(1, tenDT);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                res = rs.getInt("MaDT");
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }
}

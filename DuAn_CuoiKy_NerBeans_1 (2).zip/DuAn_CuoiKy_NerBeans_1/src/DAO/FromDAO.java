/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

/**
 *
 * @author ADMIN
 */
import java.awt.Dimension;
import javax.swing.JComponent;
import javax.swing.JDesktopPane;
public class FromDAO {
      public static void centerJIF(JDesktopPane jDesktopPane, JComponent jComponent) {
        Dimension desktopSize = jDesktopPane.getSize();
        Dimension jInternalFrameSize = jComponent.getSize();
        int width = (desktopSize.width - jInternalFrameSize.width) / 2;
        int height = (desktopSize.height - jInternalFrameSize.height) / 2;
        jComponent.setLocation(width, height);
        jComponent.setVisible(true);
    }
}

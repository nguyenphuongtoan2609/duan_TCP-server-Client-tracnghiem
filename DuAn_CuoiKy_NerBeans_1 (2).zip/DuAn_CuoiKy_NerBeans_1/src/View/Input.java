/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Input {
    public static String input_String() throws IOException{
        String str = null;
        
        boolean check = false;
        Scanner sc = new Scanner(System.in);
        while(!check){
                try{
                    str=sc.nextLine();
                    check = true;
                }catch(Exception ex){
                    check = false;
                    System.out.println(ex);
                }
         }
        return str;
    }
    public static int input_int(){
        int n=0;
        boolean check = false;
        Scanner sc = new Scanner(System.in);
        while(!check){
                try{
                    n=Integer.parseInt(sc.nextLine());
                    if(n<0){
                        check = false;
                    }else check = true;
                }catch(Exception ex){
                    check = false;
                    System.out.println("Nhap sai! Vui Long Nhap Lai");
                }
         }
        return n;
    }
    
    public static float input_float(){
        float n=0;
        boolean check = false;
        Scanner sc = new Scanner(System.in);
        while(!check){
                try{
                    n=Float.parseFloat(sc.nextLine());
                    check = true;
                }catch(Exception ex){
                    check = false;
                    System.out.println(ex);
                }
         }
        
        
        return n;
    } 
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import php_connect.ConnectPHP;

import java.net.ServerSocket;

import java.net.Socket;

/**
 *
 * @author Gum
 */
public class ServerView {

    public static void ThiTracNghiem() {
        int core = 0;
        try {
            try (ServerSocket ss = new ServerSocket(12345)) {
                System.out.println("ThiTracNghiem aldready...");
                
                Socket socket = ss.accept();
                DataInputStream dis = new DataInputStream(socket.getInputStream());
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                
                String str = ConnectPHP.getAllCauHoi();
                dos.writeUTF(str);
                String[] cauhoi = str.split("///");
                String anwClient = dis.readUTF();
                System.out.println(anwClient);
                
                String[] arrAnw = anwClient.split("///");
                int dem = 0;
                String answer = "";
                for (int i = 1; i < arrAnw.length; i = i + 2) {
                    dem++;
                    answer += dem + " " + arrAnw[i] + " - " + cauhoi[(dem * 8) - 1] + "\n";
                    if (arrAnw[i].equals(cauhoi[(dem * 9) - 1])) {
                        core++;
                    }
                }
                answer += "Diem cua ban la: " + core;
                dos.writeUTF(answer);
            }
        } catch (IOException ex) {
            Logger.getLogger(ServerView.class.getName()).log(Level.SEVERE, null, ex);
        }
        //  return core;
        //  return core;
    }

public void layketquaa(){
    LayCauHoi.Laycauhoi();
}

    public static void main(String[] args) {
        ThiTracNghiem();
        try {
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Khởi chạy máy chủ thành công");
            while (true) {
                //Tạo Thread mới khi có 1 Client kết nối thành công
                new ThreadSocket(serverSocket.accept()).start();
                System.out.println("Có 1 kết nối đến");
            }
        } catch (IOException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        LayCauHoi.Laycauhoi();
        String str = ConnectPHP.getAllCauHoi();
        System.out.println(str);
    }
}

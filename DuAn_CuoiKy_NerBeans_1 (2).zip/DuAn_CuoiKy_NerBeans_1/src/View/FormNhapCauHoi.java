package View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FormNhapCauHoi extends JFrame {
    private JTextField cauHoiField;
    private JTextField luaChonAField;
    private JTextField luaChonBField;
    private JTextField luaChonCField;
    private JTextField luaChonDField;
    private JTextField dapAnField;
    private JButton nutGui;

    public FormNhapCauHoi() {
        setTitle("Form Nhập Câu Hỏi Trắc Nghiệm");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Tạo các thành phần
        JLabel cauHoiLabel = new JLabel("Câu hỏi:");
        cauHoiField = new JTextField();

        JLabel luaChonALabel = new JLabel("Lựa chọn A:");
        luaChonAField = new JTextField();

        JLabel luaChonBLabel = new JLabel("Lựa chọn B:");
        luaChonBField = new JTextField();

        JLabel luaChonCLabel = new JLabel("Lựa chọn C:");
        luaChonCField = new JTextField();

        JLabel luaChonDLabel = new JLabel("Lựa chọn D:");
        luaChonDField = new JTextField();

        JLabel dapAnLabel = new JLabel("Đáp án đúng:");
        dapAnField = new JTextField();

        nutGui = new JButton("Gửi");

        // Thêm các thành phần vào frame
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(cauHoiLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        add(cauHoiField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(luaChonALabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        add(luaChonAField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(luaChonBLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        add(luaChonBField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(luaChonCLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        add(luaChonCField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(luaChonDLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        add(luaChonDField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(dapAnLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        add(dapAnField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 6;
        add(nutGui, gbc);

        // Thêm action listener cho nút gửi
        nutGui.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xuLyGui();
            }
        });
    }

    private void xuLyGui() {
        String cauHoi = cauHoiField.getText();
        String luaChonA = luaChonAField.getText();
        String luaChonB = luaChonBField.getText();
        String luaChonC = luaChonCField.getText();
        String luaChonD = luaChonDField.getText();
        String dapAnDung = dapAnField.getText();

        // Lưu dữ liệu vào cơ sở dữ liệu
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quiz_db", "root", "");
            String query = "INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, cauHoi);
            preparedStatement.setString(2, luaChonA);
            preparedStatement.setString(3, luaChonB);
            preparedStatement.setString(4, luaChonC);
            preparedStatement.setString(5, luaChonD);
            preparedStatement.setString(6, dapAnDung);

            preparedStatement.executeUpdate();

            JOptionPane.showMessageDialog(this, "Dữ liệu đã được lưu thành công!");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi lưu dữ liệu: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new FormNhapCauHoi().setVisible(true);
            }
        });
    }
}

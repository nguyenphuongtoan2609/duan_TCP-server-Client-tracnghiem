/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Model.Ketqua;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import php_connect.ConnectPHP;

/**
 *
 * @author ADMIN
 */
public class LayCauHoi {
     public static void Laycauhoi(){
        int core = 0;
        try {
           ServerSocket  ss = new ServerSocket(12345);
            System.out.println("ThiTracNghiem aldready...");

            Socket socket = ss.accept();
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

            String str = ConnectPHP.getAllCauHoi();
            dos.writeUTF(str);
            String[] cauhoi = str.split("///");
            String anwClient = dis.readUTF();
            System.out.println(anwClient);

            String[] arrAnw = anwClient.split("///");
            int dem = 0;
            String answer = "";
            for (int i = 1; i < arrAnw.length; i = i + 3) {
                dem++;
                answer+=dem+" "+arrAnw[i]+" - "+cauhoi[(dem * 9) - 1]+"\n";
                if (arrAnw[i].equals(cauhoi[(dem * 9) - 1])) {
                    core++;
                }
            }
            answer +="Diem cua ban la: "+core;
            Ketqua.diem = core;
            dos.writeUTF(answer);
            
        } catch (IOException ex) {
            Logger.getLogger(ServerView.class.getName()).log(Level.SEVERE, null, ex);
        }
         System.out.println(core);
    }
    }


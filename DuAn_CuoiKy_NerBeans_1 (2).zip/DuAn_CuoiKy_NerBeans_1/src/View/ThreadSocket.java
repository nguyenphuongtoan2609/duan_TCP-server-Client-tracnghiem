/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import php_connect.ConnectPHP;

/**
 *
 * @author ADMIN
 */
public class ThreadSocket extends Thread{
    Socket socket;
       int core = 0;
    public ThreadSocket(Socket pSocket){
        this.socket=pSocket;
    }
    @Override
    public void run(){
        try{
            //Tạo luồng nhận dữ liệu từ bàn phím
            DataInputStream inFromServer = new DataInputStream(System.in);
            //Tạo luồng nhận dữ liệu từ Client
            DataInputStream inFromClient = new DataInputStream(socket.getInputStream());
            //Tạo luồng gửi dữ liệu về Client
            DataOutputStream outToClient = new DataOutputStream(socket.getOutputStream());
            while(true)
            {
                //Đọc dữ liệu từ Client gửi tới rồi in ra
                String listen = inFromClient.readLine();
                System.out.println("\nClient: "+listen);
               
                System.out.println("\nServer: ");
                //Nhập dữ liệu từ bàn phím rồi gửi về Client
                String ask = inFromServer.readLine();
                outToClient.writeBytes(ask+"\n");
                String str = ConnectPHP.getAllCauHoi();
           outToClient.writeUTF(str);
            String[] cauhoi = str.split("///");
            String anwClient = inFromClient.readUTF();
            System.out.println(anwClient);

            String[] arrAnw = anwClient.split("///");
            int dem = 0;
            String answer = "";
            for (int i = 1; i < arrAnw.length; i = i + 2) {
                dem++;
                answer+=dem+" "+arrAnw[i]+" - "+cauhoi[(dem * 8) - 1]+"\n";
                if (arrAnw[i].equals(cauhoi[(dem * 8) - 1])) {
                    core++;
                }
            }
            answer +="Diem cua ban la: "+core;
            outToClient.writeUTF(answer);
            
       
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
}

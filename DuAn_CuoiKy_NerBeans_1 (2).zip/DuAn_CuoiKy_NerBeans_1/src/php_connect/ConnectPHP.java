package php_connect;
import Model.CauHoi;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ConnectPHP {
    
    public static Connection getSqlConnection ()
    {
        try {
            String url="jdbc:mysql://localhost:3306/tracnghiem";
            String user="root";
            String password="";
            Connection conn =DriverManager.getConnection(url, user, password);
            return conn;
        } catch (SQLException e) {
             System.out.println("login fail");
          e.printStackTrace();
            return null;
        }
    }
     public static String getAllCauHoi(){
//        
//        List<CauHoi> listCH = new ArrayList<>();
//        int[] socau = new int[1000];
//        Arrays.fill(socau, 0);
//        Connection conn = getSqlConnection();   
//        String sql = "SELECT * FROM tbtracnghiem";
//        //Đảo câu
//        Random rand = new Random(); 
//        int dem=0;
//        while(dem<10){
//            int k = rand.nextInt(220);
//            if(socau[k]!=1){
//                socau[k] = 1;
//                dem++;
//            }
//        }
//        dem=-1;
//        String str = "" ;
//        try {        
//            PreparedStatement ptsm = conn.prepareStatement(sql);
//            ResultSet rs = ptsm.executeQuery();
//            while(rs.next()){
//                dem++;
//                if(socau[dem]>0){
//                    str+=rs.getInt("id_made");
//                    str+="///";
//                    str+=rs.getInt("CAUHOI");
//                    str+="///";                
//                    str+=rs.getString("NOIDUNG");
//                    str+="///";
//                    str+=rs.getString("A");
//                    str+="///";
//                    str+=rs.getString("B");
//                    str+="///";
//                    str+=rs.getString("C");
//                    str+="///";
//                    str+=rs.getString("D");
//                    str+="///";
//                    str+=rs.getString("DAP_AN");
//                    str+="///";
//                }
//            }
//            
//        } catch (SQLException ex) {
//            Logger.getLogger(ConnectPHP.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        return str;
//        
//        List<CauHoi> listCH = new ArrayList<>();
//        int[] socau = new int[1000];
//        Arrays.fill(socau, 0);
//        Connection conn = getSqlConnection();   
//        String sql = "SELECT * FROM tbtracnghiem";
//        //Đảo câu
//        Random rand = new Random(); 
//        int dem=0;
//        while(dem<10){
//            int k = rand.nextInt(220);
//            if(socau[k]!=1){
//                socau[k] = 1;
//                dem++;
//            }
//        }
//        dem=-1;
//        String str = "" ;
//        try {        
//            PreparedStatement ptsm = conn.prepareStatement(sql);
//            ResultSet rs = ptsm.executeQuery();
//            while(rs.next()){
//                dem++;
//                if(socau[dem]>0){
//                    str+=rs.getInt("id_made");
//                    str+="///";
//                    str+=rs.getInt("CAUHOI");
//                    str+="///";                
//                    str+=rs.getString("NOIDUNG");
//                    str+="///";
//                    str+=rs.getString("A");
//                    str+="///";
//                    str+=rs.getString("B");
//                    str+="///";
//                    str+=rs.getString("C");
//                    str+="///";
//                    str+=rs.getString("D");
//                    str+="///";
//                    str+=rs.getString("DAP_AN");
//                    str+="///";
//                }
//            }
//            
//        } catch (SQLException ex) {
//            Logger.getLogger(ConnectPHP.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        return str;
        return null;
    }
      public static boolean getConnect(String str) {
//        boolean check = false;     
//         String[] arrStr = str.split("///");
//        String name = "root";
//        String pass = "";
//        String url = "jdbc:mysql://localhost:3306/tracnghiem";
//        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            Connection conn = DriverManager.getConnection(url, name, pass); 
//            if (conn != null) {
// System.out.println("Connected");
// check = true;
//}
//        } catch (ClassNotFoundException | SQLException e) {
//            e.printStackTrace();
//        }
//        return check;
//        //return conn;
//        boolean check = false;     
//         String[] arrStr = str.split("///");
//        String name = "root";
//        String pass = "";
//        String url = "jdbc:mysql://localhost:3306/tracnghiem";
//        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            Connection conn = DriverManager.getConnection(url, name, pass); 
//            if (conn != null) {
// System.out.println("Connected");
// check = true;
//}
//        } catch (ClassNotFoundException | SQLException e) {
//            e.printStackTrace();
//        }
//        return check;
//        //return conn;
        return false;
    }
      
       public static Connection getConnection(String databaseName, String username, String password) throws SQLException{
        String url = String.format("jdbc:mysql://localhost:3306/tracnghiem?zeroDateTimeBehavior=CONVERT_TO_NULL", databaseName);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, username, password);
            return con;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnectPHP.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public static Connection getDBConnection() throws  SQLException
    {
         String databaseName = "tracnghiem";
        String username = "root";
        String password = "";
        String url = String.format("jdbc:mysql://localhost:3306/tracnghiem?zeroDateTimeBehavior=CONVERT_TO_NULL", databaseName);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, username, password);
            return con;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnectPHP.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public static void main(String[] args) throws IOException{

    }

}
